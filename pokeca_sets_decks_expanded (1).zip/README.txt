ポケカ資産管理・カードセット／構築デッキ追加版

既存70件 + 追加42件 = 合計112商品。
追加商品は公式のカードセット、構築デッキ、関連セット名を参照した「候補登録」であり、すべての発売済み商品の網羅は保証しません。
新規商品の買取相場は確認できていません。10万円未満かも未判定です。
既存70件の参考買取額は過去のスナップショット（2026-10-31）で、現在価格ではありません。
GitHub側では index.html と data/catalog.json, data/prices.json, data/history.json を更新してください。
新規の商品名を自由入力で既に登録している場合は、IDが custom:商品名 となるため、マスタ登録商品のIDと自動で一致しません。データはブラウザに残ります。
停止したGitHub Actionsは再開しないでください。過去の更新スクリプトが価格データを上書きします。

公式商品情報:
https://www.pokemon-card.com/products/index.html
https://www.30th.pokemon-card.com/product
https://www.pokemon-card.com/rules/regulation/sv.html
